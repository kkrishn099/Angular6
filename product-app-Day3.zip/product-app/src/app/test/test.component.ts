import { Component } from "@angular/core";
import { Template } from "@angular/compiler/src/render3/r3_ast";


@Component({
 selector : 'app-test',
 template :`<h1>This is a test Component</h1>
            <p>Understanding component</p><button type="button" class="btn btn-default">Default</button>
<button type="button" class="btn btn-primary">Primary</button>
`
  ,
  styles: [`p{
    color:red;
  font-size:1.2em;}`]   
})


export class TestComponent{}
