import { Component, OnInit } from '@angular/core';
import{IProductts} from './iproductts'
import { ProductService } from './product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  pageTitle : string =""
  showImage :boolean=false
  listFilter: string=''

  products 
  constructor(private _productService:ProductService) {

   }

  ngOnInit() {
    //console.log(`Life Cycle hook method ngOnInt called`)
  //  this.products=this._productService.getProduct()
  this._productService.getProduct().subscribe((products)=>this.products=products)
  }

  toggleImage() : void{
     this.showImage = ! this.showImage
  }
  onRatingClicked(message :string):void{
    console.log(message)
    this.pageTitle ='product Application : '+message
  }

}
