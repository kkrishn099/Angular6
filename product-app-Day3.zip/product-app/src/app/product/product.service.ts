import { Injectable } from '@angular/core';
import { IProductts } from './iproductts';
import {HttpClient} from '@angular/common/http'
import { Observable ,throwError } from 'rxjs';
import{map , tap , catchError} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products :IProductts[]=[]

  private _productUrl='./assets/api/products/products.json'
  constructor(private _httpClient:HttpClient) {

   }

  // getProduct():IProductts[]{
  //   return this.products

  // }
  getProduct():Observable<IProductts[]>{
    console.log(this._httpClient.get<IProductts[]>(this._productUrl))
    return this._httpClient.get<IProductts[]>(this._productUrl)
    .pipe(tap((data)=>console.log('All Data :' +JSON.stringify(data)))//,catchError(this.handleError))
    )
    
  }
 // private handleError(){
    
 // }
}
