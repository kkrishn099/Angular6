import { Pipe, PipeTransform } from '@angular/core';
import { IProductts } from './iproductts';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(value: IProductts[], filterBy?: string): IProductts[] {
    filterBy=filterBy ?filterBy.toLocaleLowerCase():null
    return filterBy ? value.filter((product:IProductts)=>
    product.productName.toLocaleLowerCase().indexOf(filterBy)!==-1 ):value
  }

}
