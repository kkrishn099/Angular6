import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test1',
  template: `
    <p>
      test1 works!
    </p>
    <button type="button" class="btn btn-primary">Primary</button>
  `,
  styles: [`p{
  color:red;
font-size:1.2em;}`]
})
export class Test1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
