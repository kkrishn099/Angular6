import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test1',
  template: `
    <p>
      test1 works!
    </p>
    <button class="btn btn-primary">ClickHere!!</button>
  `,
  styles: [`
  p{
    color:red;
    font-size:30px;
  }
  
  `]
})
export class Test1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
