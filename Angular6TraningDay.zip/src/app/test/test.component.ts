import {Component} from '@angular/core'



@Component({
  selector :'app-test',
  template:`<h1>This is a test component</h1>
            <p>Understanding components...</p>
            `  
})

export class TestComponent{}