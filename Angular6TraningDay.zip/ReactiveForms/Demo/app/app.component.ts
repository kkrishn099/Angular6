import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
        <div class="container">
          <my-signup></my-signup>
        </div>
    `
})
export class AppComponent { }
